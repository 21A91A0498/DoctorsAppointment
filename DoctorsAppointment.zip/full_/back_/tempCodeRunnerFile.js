.then(()=>
    console.log("Connected SuccessFully to database");
)
.catch((err)=> console.log(err))
import "../styles/contact.css"
const Contact = () =>{
    return(
        <div className="contact">
            <div className="di1">
                <h2>Contact</h2>
                <h3 className="e">Make a Call: +123456</h3>
                <h3 className="e">Email: Thub@Hospital.com</h3>
            </div>
        </div>
    )
}
export default Contact